package prog5121_poe;

import javax.swing.JOptionPane;

public class PROG5121_POE {

    public static void main(String[] args) {
        //create an object for the class 'Login' 
        Login check = new Login();
        
        //call method 'registerUser()'
        String registerUser = check.registerUser();
        if (registerUser.equals("Password and Username successfully captured")) {
            JOptionPane.showMessageDialog(null, registerUser);
            //JOptionPane.showMessageDialog(null, loginUser);
            JOptionPane.showMessageDialog(null, "Welcome to EasyKanban!");

            // Proceed to task management
            Task task = new Task();
            int choice = task.showOptions();

            switch (choice) {
                case 1:
                    task.addTasks(); 
                    break;
                case 2:
                    task.displayArray();
                    int select = task.optionsSelect();
                    switch(select){
                        case 1:
                            task.displayDone();
                            break;
                        case 2:
                            task.displayDuration();
                            break;
                        case 3:
                            String Name = JOptionPane.showInputDialog("Enter the task name you looking for:");
                            task.Search(Name);
                            break;
                        case 4:
                            String developer = JOptionPane.showInputDialog("Enter the name of the developer you looking for:");
                            task.searchDeveloper(developer);
                            break;
                        case 5:  
                            String name = JOptionPane.showInputDialog("Enter the task name you wish to delete:");
                            task.Delete(name);
                            break;
                        case 6:
                            return;
                    }
                case 3:
                    return; // Terminates the program
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice.");
            }
        } else {
            // Display error message and terminate the program
            //JOptionPane.showMessageDialog(null, loginUser);
            JOptionPane.showMessageDialog(null, registerUser);
        }
    }    
}
