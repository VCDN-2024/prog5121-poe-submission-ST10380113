package prog5121_poe;

import javax.swing.JOptionPane;
public class Task {
    
    //create arrays
    static String[] arrDevName = {"Mike Smith", "Edward Harrison", "Samantha Paulson", "Glenda Oberholzer"}; //contains the names of all the developers assigned to each task
    static String[] arrTaskName = {"Create Login", "Create Add Features", "Create Reports", "Add Arrays"}; //contains the names of all tasks created
    static String[] arrID = new String[20]; //contains the generated task IDs for each task
    static int[] arrDuration = {5, 8, 2, 11}; //contains the duration of all the tasks
    static String[] arrStatus = {"To Do", "Doing", "Done", "To Do"}; //contains the status of all the tasks
    
    private int totalDuration = 0;
    int taskNumber = arrDevName.length;;
    String developerDetails;
    String taskName;
    int taskDuration;
    String taskStatus;
    String taskID;
    
    public  String getInput(String prompt){
        return JOptionPane.showInputDialog(null,prompt);
    }
    
    public int showOptions(){
        while (true){
            String input = getInput("Select an option:\n" +
                "1. Add tasks\n" +
                "2. Show report\n" +
                "3. Quit"
            );

            if (input == null){
                return 3;
            }

            try {
                int choice = Integer.parseInt(input);
                if (choice >= 1 && choice <= 3) {
                    return choice; // Return valid option
                }
            } catch (NumberFormatException e) {
                // Invalid input, do nothing
            }

            JOptionPane.showMessageDialog(null, "Invalid choice. Please select a valid option.");

            // If input is invalid, return 0
            return 0;
        }   
    }
    
    public int optionsSelect(){
        while (true){
            String input = getInput("Select an option:\n" +
                "1. Display tasks that are done\n" +
                "2. Display the task with the longest duration\n" +
                "3. Search for a task by its name\n"+
                "4. Search for tasks assigned to a developer\n"+
                "5. Delete a task\n"+
                "6. Quit"
            );

            if (input == null){
                return 6;
            }

            try {
                int choice = Integer.parseInt(input);
                if (choice >= 1 && choice <= 6) {
                    return choice; // Return valid option
                }
            } catch (NumberFormatException e) {
                // Invalid input, do nothing
            }

            JOptionPane.showMessageDialog(null, "Invalid choice. Please select a valid option.");

            // If input is invalid, return 0
            return 0;
        }   
    }
    
    public void addTasks(){
        int numTasks = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of tasks you wish to enter:"));
        
        for (int i = 0; i < numTasks; i++) {
            taskName = JOptionPane.showInputDialog("Enter the name of task " + (i + 1) + ":");
            String taskDescription;
            do {
                taskDescription = JOptionPane.showInputDialog("Describe task " + (i + 1) + ":");
                if (taskDescription == null || taskDescription.length() <= 50) {
                    JOptionPane.showMessageDialog(null, "Task successfully captured");
                    break;
                } else {
                    JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters");
                }
            } while (true);
            developerDetails = JOptionPane.showInputDialog("Enter the developers full name for task " + (i + 1) + ":");
            taskDuration = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of hours task " + (i + 1) + " would take" + ":"));
            totalDuration += taskDuration;
            
            taskID = createTaskID(taskName, taskNumber, developerDetails);
            JOptionPane.showMessageDialog(null, "Task ID: " + taskID.toUpperCase());
                        
            while (true) {
                String input = getInput("Select an option:\n" +
                    "1. To Do\n" +
                    "2. Done\n" +
                    "3. Doing"
                );

                if (input != null && !input.isEmpty()) {
                    int choice = Integer.parseInt(input);
                    if (choice == 1) {
                        taskStatus = "To Do";
                        break;
                    } else if (choice == 2) {
                        taskStatus = "Done";
                        break;
                    } else if (choice == 3) {
                        taskStatus = "Doing";
                        break;
                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid choice. Please select a valid option.");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Error: You must select an option.");
                }
            }
            
            // Print task details
            String taskDetails = printTaskDetails(taskStatus, developerDetails, taskNumber, taskName, taskDescription, taskID, taskDuration);
            JOptionPane.showMessageDialog(null, taskDetails);
            
            taskNumber++; // Increment task number for the next task 
        }
        // Display total duration
        JOptionPane.showMessageDialog(null, "Total duration of all tasks: " + returnTotalHours() + " hours");
    }
    
    public boolean checkTaskDescription(String taskDescription){
        return taskDescription != null && taskDescription.length() <= 50;
    }
    
    public String createTaskID(String taskName, int taskNumber, String developerName){
        // Extracting the first two letters of the task name
        String prefix = taskName.substring(0, Math.min(taskName.length(), 2)).toUpperCase();
        // Extracting the last three letters of the developer name
        String suffix = developerName.substring(Math.max(developerName.length() - 3, 0)).toUpperCase();

        return prefix + ":" + taskNumber + ":" + suffix;
    }
    
    public String printTaskDetails(String taskStatus, String developerDetails, int taskNumber, String taskName, String taskDescription, String taskID, int taskDuration){
        return String.format(
            "Task status: %s\nDeveloper details: %s\nTask number: %d\nTask name: %s\nTask description: %s\nTask ID: %s\nDuration: %s hours",
            taskStatus, developerDetails, taskNumber, taskName, taskDescription, taskID.toUpperCase(), taskDuration
        );
    }
    
    public int returnTotalHours(){
        return totalDuration;
    }
    
    public String displayArray(){
        String output = new String ("All tasks:\n");
        for (int i=0; i<taskNumber; i++){
            if (arrDevName[i] != null && arrTaskName[i] != null && arrID[i] != null && arrDuration[i] != 0 && arrStatus[i] != null) {
                output += "Developers Name:\t" + arrDevName[i];
                output += "Task Name:\t" + arrTaskName[i];
                output += "Task ID:\t" + arrID[i];
                output += "Task Duration:\t" + arrDuration[i];
                output += "Task Status:\t" + arrStatus[i] + "\n\n";
            } 
        }    
        JOptionPane.showMessageDialog(null, output.toString());
        return output;
    }
    
    public String displayDone(){
        String output = "Tasks that are done:\n";
        
        boolean done = false;
        for (int i = 0; i<= taskNumber; i++){
            if(arrStatus[i] != null && arrStatus[i].equalsIgnoreCase(taskStatus = "Done")){
                output = "\nTask name:\t" + arrTaskName[i];
                output += "\nDevelopers Name:\t" + arrDevName[i];
                output += "\nTask Duration:\t" + arrDuration[i];
                
                JOptionPane.showMessageDialog(null, output.toString());
                done = true;
                break;
            }
        }
        
        if (!done) {
            return "No tasks with status 'Done' found.";
        }
        else{
            return output.toString();
        }
    }
    
    public String displayDuration(){
        int maxDuration = arrDuration[0];
        int maxIndex = 0;

        for (int i = 1; i < taskNumber; i++) {
            if (arrDuration[i] > maxDuration) {
                maxDuration = arrDuration[i];
                maxIndex = i;
            }
        } 
        
        String output = "Task with the longest duration:";
        output = "\nTask name:\t" + arrTaskName[maxIndex];
        output += "Developers Name:\t" + arrDevName[maxIndex];
        output += "\nTask Duration:\t" + arrDuration[maxIndex];        

        JOptionPane.showMessageDialog(null, output);
        return output;
    }
    
    public String Search(String Name){
        boolean found = false;
        String output = new String();
        
        for (int i = 0; i<= taskNumber; i++){
            if(arrTaskName[i].equalsIgnoreCase(Name)){
                output = "\nTask name:\t" + arrTaskName[i];
                output += "Developers Name:\t" + arrDevName[i];
                output += "\nTask ID:\t" + arrID[i];
                output += "\nTask Duration:\t" + arrDuration[i];
                output += "\nTask Status:\t" + arrStatus[i];
                 
                JOptionPane.showMessageDialog(null, output.toString());  
                found = true;
                break;
            }
        }
        if(!found){
            JOptionPane.showMessageDialog(null, "Task not found. Please try again");
        }
        return output;
    }
    
    public String searchDeveloper(String developer){        
        boolean isFound = false;
        String output = new String();
        
        for (int i = 0; i<= taskNumber; i++){
            if(arrDevName[i].equalsIgnoreCase(developer)){
                output = "\nTask name:\t" + arrTaskName[i];
                output += "Developers Name:\t" + arrDevName[i];
                output += "\nTask ID:\t" + arrID[i];
                output += "\nTask Duration:\t" + arrDuration[i];
                output += "\nTask Status:\t" + arrStatus[i];
                
                JOptionPane.showMessageDialog(null, output.toString());
                isFound = true;
                break;
            }
        }
        if(!isFound){
            JOptionPane.showMessageDialog(null, "Developer not found. Please try again");
        }
        return output;
    }
    
    public boolean Delete(String name) {
        // Temporary arrays to store remaining tasks
        String[] temparrTaskName = new String[taskNumber];
        String[] temparrDevName = new String[taskNumber];
        String[] temparrID = new String[taskNumber];
        int[] temparrDuration = new int[taskNumber];
        String[] temparrStatus = new String[taskNumber];

        int j = 0;
        boolean deleted = false;

        for (int i = 0; i < taskNumber; i++) {
            if (arrTaskName[i] != null && !arrTaskName[i].equalsIgnoreCase(name)) {
                temparrTaskName[j] = arrTaskName[i];
                temparrDevName[j] = arrDevName[i];
                temparrID[j] = arrID[i];
                temparrDuration[j] = arrDuration[i];
                temparrStatus[j] = arrStatus[i];
                j++;
            } else if (arrTaskName[i] != null && arrTaskName[i].equalsIgnoreCase(name)) {
                deleted = true;
            }
        }

        if (!deleted) {
            JOptionPane.showMessageDialog(null, "Task could not be deleted. Please try again.");
        } else {
            // Update the original arrays with the remaining tasks
            arrTaskName = new String[j];
            arrDevName = new String[j];
            arrID = new String[j];
            arrDuration = new int[j];
            arrStatus = new String[j];

            for (int k = 0; k < j; k++) {
                arrTaskName[k] = temparrTaskName[k];
                arrDevName[k] = temparrDevName[k];
                arrID[k] = temparrID[k];
                arrDuration[k] = temparrDuration[k];
                arrStatus[k] = temparrStatus[k];
            }

            // Decrement the task number
            taskNumber--;

            JOptionPane.showMessageDialog(null, "Task successfully deleted!");
                        
        }
        return true;
    }
}