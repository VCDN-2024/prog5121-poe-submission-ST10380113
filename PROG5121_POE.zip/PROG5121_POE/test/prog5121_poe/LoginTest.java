
package prog5121_poe;

import org.junit.Test;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class LoginTest {
    
    public LoginTest() {
    }
    
    Login login = new Login();

    @Test
    public void testCheckUserNameCorreclyFormatted() {
        boolean value = login.checkUserName("kyl_1");
        assertTrue(value);
    }
    
    @Test
    public void testCheckUserNameIncorreclyFormatted() {
        boolean value = login.checkUserName("kyle!!!!!!!");
        assertFalse(value);
    }

    @Test
    public void testCheckPasswordComplexitySuccess() {        
        boolean value = login.checkPasswordComplexity("Ch&&sec@ke99!");
        assertTrue(value);
    }

    @Test
    public void testCheckPasswordComplexityFailure() {        
        boolean value = login.checkPasswordComplexity("password");
        assertFalse(value);
    }
        
    @Test
    public void testLoginUser() {
    }

    @Test
    public void testRegisterUser() {
    }

    @Test
    public void testReturnLoginStatus() {
    }
    
}
